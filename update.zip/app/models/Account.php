<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    //
}
