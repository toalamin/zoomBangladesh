# Generiere finderbox Version vom ACE Design

    $> lessc --clean-css="--s1 --advanced --compatibility=ie8" ./assets/css/less/ace.less ./dist/css/ace-fb.min.css

dann `ace-fb.min.css` einbinden anstatt `ace.min.css`

# Einstellungen anpassen

variables-fb.less bearbeiten
