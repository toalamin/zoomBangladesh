<?php

use Illuminate\Database\Seeder;

class PeopleSaySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
