@extends('backend_layouts.app')
@section('title')
Dashboard
@endsection


@section('css')


@endsection


@section('content')
<!-- /section:basics/content.breadcrumbs -->
<div class="page-content">
    <!-- #section:settings.box -->
    <!-- /.ace-settings-container -->

    <div class="row">
        <div class="col-xs-12">

            <table class="table table-bordered text-center">
                <tr>
                    <th><center><img height="200px" width="200px" src="frontant/images/ezb-foundation.png" class="img-thumbnail"/></center></th>
                </tr>
                <tr>
                    <th><center><h1>Wellcome to Zoom Bangladesh</h1></center></th>
                </tr>
            </table>

            <!-- PAGE CONTENT ENDS -->
        </div><!-- /.col -->
    </div><!-- /.row -->
</div><!-- /.page-content -->

@endsection