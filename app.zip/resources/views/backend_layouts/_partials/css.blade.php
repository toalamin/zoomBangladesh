<!-- bootstrap & fontawesome -->

<!-- Favicon and Touch Icons -->
<link href="{{ asset('frontant/images/favicon_.png') }}" rel="shortcut icon" type="image/png">

<link rel="stylesheet" href="{{ asset('backend/asset/assets/css/bootstrap.css')}}" />
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/font-awesome.css')}}" />
  
<!-- page specific plugin style  assets -->
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/jquery-ui.custom.css')}}" />
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/chosen.css')}}" />
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/bootstrap-datepicker3.css')}}" />
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/bootstrap-timepicker.css')}}" />
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/daterangepicker.css')}}" />
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/bootstrap-datetimepicker.css')}}" />
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/colorpicker.css')}}" />
<!-- text fonts -->  
<link rel="stylesheet" href="{{  asset('backend/asset/assets/css/ace-fonts.css')}}" />

<!-- ace styles -->
<link rel="stylesheet" href="{{ asset('backend/asset/assets/css/ace.css')}}" class="ace-main-stylesheet" id="main-ace-style" />

<!--[if lte IE 9]>
			<link rel="stylesheet" href="../assets/css/ace-part2.css" class="ace-main-stylesheet" />
		<![endif]-->

<!--[if lte IE 9]>
		  <link rel="stylesheet" href="../assets/css/ace-ie.css" />
		<![endif]-->

<!-- inline styles related to this page -->

<!-- ace settings handler -->
<script src="{{ asset('backend/asset/assets/js/ace-extra.js')}}"></script>
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>