<!-- end wrapper -->

<!-- Footer Scripts -->
<!-- JS | Calendar Event Data -->
<script src="{{ asset('frontant/js/calendar-events-data.js') }}"></script>
<!-- JS | Custom script for all pages -->
<script src="{{ asset('frontant/js/custom.js') }}"></script>

<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  
      (Load Extensions only on Local File Systems ! 
       The following part can be removed on Server for On Demand Loading) -->
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.carousel.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.kenburn.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.layeranimation.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.migration.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.navigation.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.parallax.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.slideanims.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.video.min.js') }}"></script>
<script type="text/javascript" src="{{ asset('frontant/js/revolution.extension.actions.min.js') }}"></script>