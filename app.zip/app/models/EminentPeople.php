<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class EminentPeople extends Model
{
    protected $table='eminent_people';
}
